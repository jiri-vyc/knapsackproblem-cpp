#include "BruteKnapsackSolver.h"

using namespace std;



bool BruteKnapsackSolver::IsPerspective(Item node)
{
	return true;
}

