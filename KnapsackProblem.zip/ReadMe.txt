========================================================================
    APPLICATION : KnapsackProblem Overview
========================================================================
! DynamicKnapsackSolver and BoundKnapsackSolver not yet finished !

how to run program: KnapsackProblem.exe file_name [solve_method] [r]
where solve_method is chosen method, can be: "brute", "heuristic", "bound" or "dynamic" (without "")
r is optional parameter for brute and bound methods, making the traversing of state-space recursive. Otherwise (priority) Queue is used


/////////////////////////////////////////////////////////////////////////////
